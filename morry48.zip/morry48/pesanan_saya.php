<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['id_user'])) {
    header('Location: login.php');
    exit;
}

$id_user = (int)$_SESSION['id_user'];

$sql = "SELECT * FROM pesanan WHERE id_user = ? ORDER BY tanggal_pesanan DESC";
$stmt = mysqli_prepare($koneksi, $sql);
mysqli_stmt_bind_param($stmt, 'i', $id_user);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// helper untuk warna badge
function badgePembayaran($status) {
    switch ($status) {
        case 'Lunas': return 'bg-success';
        case 'Ditolak': return 'bg-danger';
        case 'Menunggu Konfirmasi': return 'bg-info text-dark';
        case 'Menunggu Pembayaran': return 'bg-warning text-dark';
        default: return 'bg-secondary';
    }
}
function badgePengiriman($status) {
    switch ($status) {
        case 'Sampai': return 'bg-success';
        case 'Dikirim': return 'bg-info text-dark';
        case 'Belum Dikirim': return 'bg-warning text-dark';
        default: return 'bg-secondary';
    }
}
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Pesanan Saya - Morry48 Store</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet" crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4">
    <a class="navbar-brand fw-bold" href="index.php">Morry48 Store</a>
</nav>

<div class="container mt-4">

    <!-- Header + tombol beranda -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="m-0">Pesanan Saya</h2>
        <a href="index.php" class="btn btn-outline-secondary">← Beranda</a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-striped table-bordered mb-0 text-center align-middle">
                <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>Tanggal</th>
                    <th>Total</th>
                    <th>Status Pembayaran</th>
                    <th>Status Pengiriman</th>
                    <th>Resi</th>
                    <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $no = 1;
                while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= htmlspecialchars($row['tanggal_pesanan']); ?></td>
                        <td>Rp <?= number_format($row['total'], 0, ',', '.'); ?></td>
                        <td>
                            <span class="badge <?= badgePembayaran($row['status_Pembayaran']); ?>">
                                <?= htmlspecialchars($row['status_Pembayaran']); ?>
                            </span>
                        </td>
                        <td>
                            <span class="badge <?= badgePengiriman($row['status_pengiriman']); ?>">
                                <?= htmlspecialchars($row['status_pengiriman']); ?>
                            </span>
                        </td>
                        <td><?= !empty($row['resi_pengiriman']) ? htmlspecialchars($row['resi_pengiriman']) : '-'; ?></td>
                        <td>
                            <?php if ($row['status_Pembayaran'] == 'Menunggu Pembayaran'
                                   || $row['status_Pembayaran'] == 'Ditolak'): ?>
                                <a href="upload_bukti.php?id=<?= (int)$row['id_pesanan']; ?>"
                                   class="btn btn-sm btn-success">
                                    Upload Bukti
                                </a>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>

                <?php if ($no === 1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">
                            Belum ada pesanan.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        crossorigin="anonymous"></script>
</body>
</html>
