<?php
session_start();
include '../koneksi.php';

// TODO: cek apakah user admin

$id_pesanan = (int)($_GET['id'] ?? 0);
$q = mysqli_query($koneksi,
     "SELECT * FROM pesanan WHERE id_pesanan = $id_pesanan");
$pesanan = mysqli_fetch_assoc($q);
if (!$pesanan) {
    die("Pesanan tidak ditemukan");
}
?>
<!doctype html>
<html>
<head>
    <title>Edit Pesanan</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>
<body class="container mt-4">
    <h3>Edit Pesanan #<?= $id_pesanan ?></h3>

    <?php if ($pesanan['bukti_Transfer']) : ?>
        <p>Bukti Transfer:</p>
        <img src="../upload/bukti_transfer/<?= htmlspecialchars($pesanan['bukti_Transfer']) ?>"
             style="max-width:300px">
    <?php else: ?>
        <p><em>Belum ada bukti transfer.</em></p>
    <?php endif; ?>

    <form action="proses_update_pesanan.php" method="post" class="mt-3">
        <input type="hidden" name="id_pesanan" value="<?= $id_pesanan ?>">

        <div class="mb-3">
            <label>Status Pembayaran</label>
            <select name="status_Pembayaran" class="form-control">
                <?php
                $opsiBayar = ['Menunggu Pembayaran','Menunggu Konfirmasi','Lunas','Ditolak'];
                foreach ($opsiBayar as $s) {
                    $sel = $s == $pesanan['status_Pembayaran'] ? 'selected' : '';
                    echo "<option value='$s' $sel>$s</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Status Pengiriman</label>
            <select name="status_pengiriman" class="form-control">
                <?php
                $opsiKirim = ['Belum Dikirim','Dikirim','Sampai'];
                foreach ($opsiKirim as $s) {
                    $sel = $s == $pesanan['status_pengiriman'] ? 'selected' : '';
                    echo "<option value='$s' $sel>$s</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label>No. Resi Pengiriman</label>
            <input type="text" name="resi_pengiriman"
                   value="<?= htmlspecialchars($pesanan['resi_pengiriman']) ?>"
                   class="form-control">
        </div>

        <button type="submit" class="btn btn-success">Simpan Perubahan</button>
    </form>
</body>
</html>
