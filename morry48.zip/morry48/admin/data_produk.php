<?php
include 'config/koneksi.php';
$result = mysqli_query($conn, "SELECT * FROM produk");
?>
<h2>Data Produk</h2>
<a href="tambah_produk.php">+ Tambah Produk</a>
<table border="1" cellpadding="10">
  <tr>
    <th>No</th>
    <th>Nama Produk</th>
    <th>Harga</th>
    <th>Gambar</th>
    <th>Aksi</th>
  </tr>
  <?php $no = 1; while ($row = mysqli_fetch_assoc($result)) { ?>
  <tr>
    <td><?= $no++; ?></td>
    <td><?= $row['nama_produk']; ?></td>
    <td>Rp<?= number_format($row['harga'], 0, ',', '.'); ?></td>
    <td><img src="upload/<?= $row['gambar']; ?>" width="100"></td>
    <td><a href="hapus_produk.php?id=<?= $row['id_produk']; ?>">Hapus</a></td>
  </tr>
  <?php } ?>
</table>
