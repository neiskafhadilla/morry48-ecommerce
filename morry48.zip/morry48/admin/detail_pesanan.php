<?php
include '../config/koneksi.php';
$id = $_GET['id'];
$pesanan = mysqli_query($koneksi, "SELECT * FROM pesanan WHERE id_pesanan='$id'");
$p = mysqli_fetch_assoc($pesanan);
$detail = mysqli_query($koneksi, "SELECT * FROM detail_pesanan JOIN produk ON detail_pesanan.id_produk = produk.id_produk WHERE id_pesanan='$id'");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Detail Pesanan #<?= $id; ?> - Morry48</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
  <h3>Detail Pesanan #<?= $id; ?></h3>
  <p><strong>Nama:</strong> <?= htmlspecialchars($p['nama']); ?><br>
     <strong>Alamat:</strong> <?= htmlspecialchars($p['alamat']); ?><br>
     <strong>Telepon:</strong> <?= htmlspecialchars($p['telepon']); ?><br>
     <strong>Tanggal:</strong> <?= $p['tanggal']; ?></p>

  <div class="table-responsive shadow">
    <table class="table table-bordered bg-white">
      <thead class="table-dark">
        <tr>
          <th>No</th>
          <th>Produk</th>
          <th>Jumlah</th>
          <th>Harga Satuan</th>
          <th>Subtotal</th>
        </tr>
      </thead>
      <tbody>
        <?php $no=1; $total=0; while($d=mysqli_fetch_assoc($detail)) {
          $subtotal=$d['jumlah']*$d['harga']; $total+=$subtotal; ?>
        <tr>
          <td><?= $no++; ?></td>
          <td><?= htmlspecialchars($d['nama_produk']); ?></td>
          <td><?= $d['jumlah']; ?></td>
          <td>Rp<?= number_format($d['harga'], 0, ',', '.'); ?></td>
          <td>Rp<?= number_format($subtotal, 0, ',', '.'); ?></td>
        </tr>
        <?php } ?>
      </tbody>
      <tfoot class="fw-bold">
        <tr>
          <td colspan="4" class="text-end">Total</td>
          <td>Rp<?= number_format($total, 0, ',', '.'); ?></td>
        </tr>
      </tfoot>
    </table>
  </div>

  <a href="pesanan.php" class="btn btn-secondary mt-3">Kembali</a>
</div>

</body>
</html>
