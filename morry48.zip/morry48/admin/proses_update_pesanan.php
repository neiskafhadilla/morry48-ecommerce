<?php
session_start();
include '../koneksi.php';

// TODO: cek admin

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_pesanan       = (int)$_POST['id_pesanan'];
    $statusPembayaran = $_POST['status_Pembayaran'];
    $statusKirim      = $_POST['status_pengiriman'];
    $resi             = $_POST['resi_pengiriman'];

    $sql = "UPDATE pesanan
            SET status_Pembayaran = ?, status_pengiriman = ?, resi_pengiriman = ?
            WHERE id_pesanan = ?";
    $stmt = mysqli_prepare($koneksi, $sql);
    mysqli_stmt_bind_param($stmt, 'sssi',
        $statusPembayaran, $statusKirim, $resi, $id_pesanan);
    mysqli_stmt_execute($stmt);

    header('Location: daftar_pesanan.php'); // sesuaikan dengan halaman daftar adminmu
    exit;
}
