<?php
include '../config/koneksi.php';
$query = mysqli_query($koneksi, "SELECT * FROM pesanan ORDER BY id_pesanan DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Daftar Pesanan - Admin Morry48</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3>📜 Daftar Pesanan</h3>
    <a href="daftar_produk.php" class="btn btn-secondary">Kembali ke Produk</a>
  </div>

  <div class="table-responsive shadow">
    <table class="table table-bordered table-hover align-middle bg-white">
      <thead class="table-dark">
        <tr>
          <th>ID Pesanan</th>
          <th>Nama</th>
          <th>Alamat</th>
          <th>Telepon</th>
          <th>Tanggal</th>
          <th>Detail</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = mysqli_fetch_assoc($query)) { ?>
        <tr>
          <td><?= $row['id_pesanan']; ?></td>
          <td><?= htmlspecialchars($row['nama']); ?></td>
          <td><?= htmlspecialchars($row['alamat']); ?></td>
          <td><?= htmlspecialchars($row['telepon']); ?></td>
          <td><?= $row['tanggal']; ?></td>
          <td>
            <a href="detail_pesanan.php?id=<?= $row['id_pesanan']; ?>" class="btn btn-sm btn-info">Lihat</a>
          </td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</div>

</body>
</html>
