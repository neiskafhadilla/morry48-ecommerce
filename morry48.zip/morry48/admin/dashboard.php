<?php
session_start();
include '../koneksi.php';

// =====================
// CEK ADMIN (opsional)
// =====================
// if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
//     header('Location: ../login.php');
//     exit;
// }

// =====================
// UPDATE PESANAN (inline)
// =====================
$flash_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_pesanan'])) {
    $id_pesanan       = (int)$_POST['id_pesanan'];
    $statusPembayaran = $_POST['status_Pembayaran'] ?? 'Menunggu Pembayaran';
    $statusPengiriman = $_POST['status_pengiriman'] ?? 'Belum Dikirim';
    $resi             = trim($_POST['resi_pengiriman'] ?? '');

    $sql = "UPDATE pesanan
            SET status_Pembayaran = ?, status_pengiriman = ?, resi_pengiriman = ?
            WHERE id_pesanan = ?";

    $stmt = mysqli_prepare($koneksi, $sql);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'sssi',
            $statusPembayaran,
            $statusPengiriman,
            $resi,
            $id_pesanan
        );
        mysqli_stmt_execute($stmt);
        $flash_message = 'Pesanan #' . $id_pesanan . ' berhasil diperbarui.';
    } else {
        $flash_message = 'Gagal update pesanan: ' . mysqli_error($koneksi);
    }
}

// =====================
// DATA RINGKASAN
// =====================
$totalPesanan = mysqli_fetch_row(
    mysqli_query($koneksi, "SELECT COUNT(*) FROM pesanan")
)[0];

$menungguBayar = mysqli_fetch_row(
    mysqli_query($koneksi, "SELECT COUNT(*) FROM pesanan 
                            WHERE status_Pembayaran IN ('Menunggu Pembayaran','Menunggu Konfirmasi')")
)[0];

$belumDikirim = mysqli_fetch_row(
    mysqli_query($koneksi, "SELECT COUNT(*) FROM pesanan 
                            WHERE status_pengiriman = 'Belum Dikirim'")
)[0];

// Ambil daftar pesanan & produk
$pesanan = mysqli_query($koneksi, "SELECT * FROM pesanan ORDER BY tanggal_pesanan DESC LIMIT 50");
$produk  = mysqli_query($koneksi, "SELECT * FROM produk ORDER BY id_produk DESC");
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Dashboard Admin - Morry48 Store</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet" crossorigin="anonymous">
    <style>
        body { background-color: #f5f5f5; }
        .card-summary { min-height: 100px; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark bg-dark px-4">
    <a class="navbar-brand fw-bold" href="#">Dashboard Admin Morry48</a>
    <div class="d-flex">
        <a href="../index.php" class="btn btn-outline-light btn-sm me-2">Lihat Toko</a>
        <a href="../logout.php" class="btn btn-outline-light btn-sm">Logout</a>
    </div>
</nav>

<div class="container my-4">

    <!-- FLASH MESSAGE -->
    <?php if ($flash_message): ?>
        <div class="alert alert-info">
            <?= htmlspecialchars($flash_message); ?>
        </div>
    <?php endif; ?>

    <!-- RINGKASAN -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card card-summary shadow-sm border-0">
                <div class="card-body">
                    <h6 class="text-muted">Total Pesanan</h6>
                    <h3 class="fw-bold"><?= $totalPesanan; ?></h3>
                    <small class="text-muted">Semua pesanan yang pernah masuk</small>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-summary shadow-sm border-0">
                <div class="card-body">
                    <h6 class="text-muted">Menunggu Pembayaran / Konfirmasi</h6>
                    <h3 class="fw-bold"><?= $menungguBayar; ?></h3>
                    <small class="text-muted">Butuh dicek & dikonfirmasi</small>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-summary shadow-sm border-0">
                <div class="card-body">
                    <h6 class="text-muted">Belum Dikirim</h6>
                    <h3 class="fw-bold"><?= $belumDikirim; ?></h3>
                    <small class="text-muted">Pesanan sudah bayar tapi belum dikirim</small>
                </div>
            </div>
        </div>
    </div>

    <!-- TAB NAV -->
    <ul class="nav nav-tabs mb-3" id="adminTab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="pesanan-tab" data-bs-toggle="tab"
                    data-bs-target="#pesanan" type="button" role="tab">
                Pesanan
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="produk-tab" data-bs-toggle="tab"
                    data-bs-target="#produk" type="button" role="tab">
                Produk
            </button>
        </li>
    </ul>

    <div class="tab-content" id="adminTabContent">
        <!-- TAB PESANAN -->
        <div class="tab-pane fade show active" id="pesanan" role="tabpanel"
             aria-labelledby="pesanan-tab">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="mb-3">Pesanan Terbaru</h5>
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered align-middle">
                            <thead class="table-dark">
                            <tr>
                                <th>No</th>
                                <th>Tanggal</th>
                                <th>Nama</th>
                                <th>Total</th>
                                <th>Status Pembayaran</th>
                                <th>Status Pengiriman</th>
                                <th>Resi</th>
                                <th>Bukti</th>
                                <th>Aksi</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $no = 1; while ($row = mysqli_fetch_assoc($pesanan)) : ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td><?= htmlspecialchars($row['tanggal_pesanan']); ?></td>
                                    <td><?= htmlspecialchars($row['nama_pelanggan']); ?></td>
                                    <td>Rp <?= number_format($row['total'], 0, ',', '.'); ?></td>
                                    <td>
                                        <form method="post" class="d-flex gap-1">
                                            <input type="hidden" name="id_pesanan"
                                                   value="<?= $row['id_pesanan']; ?>">
                                            <select name="status_Pembayaran"
                                                    class="form-select form-select-sm">
                                                <?php
                                                $opsiBayar = ['Menunggu Pembayaran', 'Menunggu Konfirmasi', 'Lunas', 'Ditolak'];
                                                foreach ($opsiBayar as $s) {
                                                    $sel = ($s == $row['status_Pembayaran']) ? 'selected' : '';
                                                    echo "<option value=\"$s\" $sel>$s</option>";
                                                }
                                                ?>
                                            </select>
                                    </td>
                                    <td>
                                            <select name="status_pengiriman"
                                                    class="form-select form-select-sm">
                                                <?php
                                                $opsiKirim = ['Belum Dikirim', 'Dikirim', 'Sampai'];
                                                foreach ($opsiKirim as $s) {
                                                    $sel = ($s == $row['status_pengiriman']) ? 'selected' : '';
                                                    echo "<option value=\"$s\" $sel>$s</option>";
                                                }
                                                ?>
                                            </select>
                                    </td>
                                    <td style="min-width: 140px;">
                                            <input type="text" name="resi_pengiriman"
                                                   class="form-control form-control-sm"
                                                   value="<?= htmlspecialchars($row['resi_pengiriman']); ?>"
                                                   placeholder="No. Resi">
                                    </td>
                                    <td>
                                        <?php if (!empty($row['bukti_Transfer'])): ?>
                                            <a href="../upload/bukti_transfer/<?= htmlspecialchars($row['bukti_Transfer']); ?>"
                                               target="_blank" class="btn btn-sm btn-outline-primary">
                                                Lihat
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted small">Tidak ada</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                            <button type="submit" name="update_pesanan"
                                                    value="1" class="btn btn-sm btn-success mb-1">
                                                Simpan
                                            </button>
                                            <a href="edit_pesanan.php?id=<?= $row['id_pesanan']; ?>"
                                               class="btn btn-sm btn-secondary">
                                                Detail
                                            </a>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>

                            <?php if ($no === 1): ?>
                                <tr>
                                    <td colspan="9" class="text-center text-muted">
                                        Belum ada pesanan.
                                    </td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <small class="text-muted">
                        Gunakan tombol <strong>Simpan</strong> di setiap baris untuk
                        mengupdate status pembayaran, status pengiriman, dan resi.
                    </small>
                </div>
            </div>
        </div>

        <!-- TAB PRODUK -->
        <div class="tab-pane fade" id="produk" role="tabpanel"
             aria-labelledby="produk-tab">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="mb-0">Kelola Produk</h5>
                        <a href="tambah_produk.php" class="btn btn-sm btn-primary">
                            + Tambah Produk
                        </a>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-striped table-bordered align-middle">
                            <thead class="table-dark">
                            <tr>
                                <th>No</th>
                                <th>Gambar</th>
                                <th>Nama Produk</th>
                                <th>Harga</th>
                                <th>Aksi</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $no = 1; while ($p = mysqli_fetch_assoc($produk)) : ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td style="width: 80px;">
                                        <?php if (!empty($p['gambar'])): ?>
                                            <img src="upload/<?= htmlspecialchars($p['gambar']); ?>"
                                                 alt="gambar" class="img-fluid">
                                        <?php else: ?>
                                            <span class="text-muted small">Tidak ada</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($p['nama_produk']); ?></td>
                                    <td>Rp <?= number_format($p['harga'], 0, ',', '.'); ?></td>
                                    <td style="white-space: nowrap;">
                                        <a href="edit_produk.php?id=<?= $p['id_produk']; ?>"
                                           class="btn btn-sm btn-warning">
                                            Edit
                                        </a>
                                        <a href="hapus_produk.php?id=<?= $p['id_produk']; ?>"
                                           class="btn btn-sm btn-danger"
                                           onclick="return confirm('Yakin ingin menghapus produk ini?');">
                                            Hapus
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>

                            <?php if ($no === 1): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted">
                                        Belum ada produk.
                                    </td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <small class="text-muted">
                        Produk yang ada di sini akan tampil di halaman utama Morry48 Store.
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        crossorigin="anonymous"></script>
</body>
</html>
