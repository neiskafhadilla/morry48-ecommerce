<?php
// Hubungkan ke database
include 'config/koneksi.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pesanan | Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <a href="../index.php" class="btn btn-secondary mb-3">← Kembali ke Website</a>
    <div class="card shadow">
        <div class="card-header bg-dark text-white">
            <h4 class="mb-0">📦 Daftar Pesanan</h4>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped text-center align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Nama Pelanggan</th>
                        <th>Email</th>
                        <th>Tanggal Pesanan</th>
                        <th>Total Belanja</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Gunakan variabel koneksi sesuai file koneksi.php kamu
                    // Pastikan di koneksi.php ada baris seperti:
                    // $conn = mysqli_connect("localhost", "root", "", "db_morry48");

                    $no = 1;
                    $query = "SELECT id_pesanan, nama_pelanggan, email, tanggal_pesanan, total FROM pesanan ORDER BY tanggal_pesanan DESC";
                    $result = mysqli_query($conn, $query);

                    if (!$result) {
                        echo "<tr><td colspan='6' class='text-danger'>Query Error: " . mysqli_error($conn) . "</td></tr>";
                    } elseif (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>
                                <td>{$no}</td>
                                <td>{$row['nama_pelanggan']}</td>
                                <td>{$row['email']}</td>
                                <td>{$row['tanggal_pesanan']}</td>
                                <td>Rp " . number_format($row['total'], 0, ',', '.') . "</td>
                                <td>
                                    <a href='detail_pesanan.php?id={$row['id_pesanan']}' class='btn btn-info btn-sm'>Detail</a>
                                </td>
                            </tr>";
                            $no++;
                        }
                    } else {
                        echo "<tr><td colspan='6' class='text-muted'>Belum ada pesanan.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>
