<?php
session_start();
include '../koneksi.php';   // koneksi ada di folder atas (root)

// ambil semua produk
$result = mysqli_query($koneksi, "SELECT * FROM produk");
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Daftar Produk</title>
</head>
<body>
    <h2>Daftar Produk</h2>
    <a href="tambah_produk.php">+ Tambah Produk</a><br><br>

    <table border="1" cellpadding="8" cellspacing="0">
        <tr>
            <th>ID</th>
            <th>Nama Produk</th>
            <th>Deskripsi</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Gambar</th>
        </tr>

        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
        <tr>
            <td><?= $row['id_produk']; ?></td>
            <td><?= $row['nama_produk']; ?></td>
            <td><?= $row['deskripsi']; ?></td>
            <td><?= $row['harga']; ?></td>
            <td><?= $row['stok']; ?></td>
            <td>
                <?php if (!empty($row['gambar'])) : ?>
                    <img src="upload/<?= $row['gambar']; ?>" width="80">
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
