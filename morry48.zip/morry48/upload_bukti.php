<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['id_user'])) {
    header('Location: login.php');
    exit;
}

$id_user    = $_SESSION['id_user'];
$id_pesanan = (int)($_GET['id'] ?? 0);

// Pastikan pesanan milik user ini
$sql  = "SELECT * FROM pesanan WHERE id_pesanan = ? AND id_user = ?";
$stmt = mysqli_prepare($koneksi, $sql);
mysqli_stmt_bind_param($stmt, 'ii', $id_pesanan, $id_user);
mysqli_stmt_execute($stmt);
$pesanan = mysqli_stmt_get_result($stmt)->fetch_assoc();

if (!$pesanan) {
    die("Pesanan tidak ditemukan.");
}
?>
<!doctype html>
<html>
<head>
    <title>Upload Bukti Pembayaran</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
<body class="container mt-4">
    <h3>Upload Bukti Pembayaran untuk Pesanan #<?= $id_pesanan ?></h3>
    <p>Total: Rp <?= number_format($pesanan['total'], 0, ',', '.') ?></p>

    <form action="proses_upload_bukti.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id_pesanan" value="<?= $id_pesanan ?>">
        <div class="mb-3">
            <label class="form-label">Pilih File Bukti Transfer (jpg,png,pdf)</label>
            <input type="file" name="bukti" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">Kirim Bukti</button>
    </form>
</body>
</html>
