<?php
session_start();
include 'koneksi.php';

// Ambil ID produk
$id_produk = (int)($_GET['id'] ?? 0);

// Ambil data produk dari database
if ($id_produk) {
    $sql = "SELECT * FROM produk WHERE id_produk = ?";
    $stmt = mysqli_prepare($koneksi, $sql);
    mysqli_stmt_bind_param($stmt, 'i', $id_produk);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $produk = mysqli_fetch_assoc($result);
}

if (!$produk) {
    echo "<script>alert('Produk tidak ditemukan!');window.location='index.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail Produk - Morry48 Store</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container my-5">
    <h1 class="mb-3"><?= htmlspecialchars($produk['nama_produk']); ?></h1>
    <div class="row">
        <div class="col-md-6">
            <img src="admin/upload/<?= htmlspecialchars($produk['gambar']); ?>" class="img-fluid" alt="<?= htmlspecialchars($produk['nama_produk']); ?>">
        </div>
        <div class="col-md-6">
            <h3>Rp <?= number_format($produk['harga'], 0, ',', '.'); ?></h3>
            <p><?= htmlspecialchars($produk['deskripsi']); ?></p>
            <a href="keranjang.php?add=<?= $produk['id_produk']; ?>" class="btn btn-primary">Tambah ke Keranjang</a>
            <a href="index.php" class="btn btn-secondary">Kembali ke Beranda</a>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
