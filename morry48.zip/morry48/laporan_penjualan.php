<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
include 'koneksi.php';

if (!isset($_SESSION['level']) || $_SESSION['level'] != 'admin') {
    echo "<script>alert('Akses ditolak! Anda bukan admin.');window.location='login.php';</script>";
    exit;
}

// ambil filter tanggal
$dari   = $_GET['dari']   ?? '';
$sampai = $_GET['sampai'] ?? '';

$conditionsPesanan = ["status_Pembayaran = 'Lunas'"];
$conditionsProduk  = ["p.status_Pembayaran = 'Lunas'"];

if ($dari !== '') {
    $d = mysqli_real_escape_string($koneksi, $dari);
    $conditionsPesanan[] = "DATE(tanggal_pesanan) >= '$d'";
    $conditionsProduk[]  = "DATE(p.tanggal_pesanan) >= '$d'";
}
if ($sampai !== '') {
    $s = mysqli_real_escape_string($koneksi, $sampai);
    $conditionsPesanan[] = "DATE(tanggal_pesanan) <= '$s'";
    $conditionsProduk[]  = "DATE(p.tanggal_pesanan) <= '$s'";
}

$wherePesanan = 'WHERE ' . implode(' AND ', $conditionsPesanan);
$whereProduk  = 'WHERE ' . implode(' AND ', $conditionsProduk);

// ambil pesanan lunas
$pesananQ = mysqli_query(
    $koneksi,
    "SELECT * FROM pesanan $wherePesanan ORDER BY tanggal_pesanan ASC"
);

$pesananData   = [];
$jumlahPesanan = 0;
$totalOmzet    = 0;

while ($row = mysqli_fetch_assoc($pesananQ)) {
    $pesananData[] = $row;
    $jumlahPesanan++;
    $totalOmzet += (float)$row['total'];
}

$rata2 = $jumlahPesanan > 0 ? $totalOmzet / $jumlahPesanan : 0;

// produk terlaris
$sqlProduk = "
    SELECT dp.id_produk,
           dp.nama_produk,
           SUM(dp.jumlah) AS total_jumlah,
           SUM(dp.harga * dp.jumlah) AS total_omzet
    FROM detail_pesanan dp
    JOIN pesanan p ON p.id_pesanan = dp.id_pesanan
    $whereProduk
    GROUP BY dp.id_produk, dp.nama_produk
    ORDER BY total_jumlah DESC";

$topProduk = mysqli_query($koneksi, $sqlProduk);
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Laporan Penjualan - Admin Morry48</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet" crossorigin="anonymous">
    <style> body { background-color: #f5f5f5; } </style>
</head>
<body>

<nav class="navbar navbar-dark bg-dark px-4">
    <a class="navbar-brand fw-bold" href="halamanutama.php">Dashboard Admin Morry48</a>
</nav>

<div class="container my-4">
    <h2 class="mb-3">Laporan Penjualan</h2>

    <!-- FILTER TANGGAL -->
    <form method="get" class="row g-3 mb-4">
        <div class="col-md-3">
            <label class="form-label">Dari Tanggal</label>
            <input type="date" name="dari" class="form-control" value="<?= htmlspecialchars($dari); ?>">
        </div>
        <div class="col-md-3">
            <label class="form-label">Sampai Tanggal</label>
            <input type="date" name="sampai" class="form-control" value="<?= htmlspecialchars($sampai); ?>">
        </div>
        <div class="col-md-3 d-flex align-items-end">
            <button type="submit" class="btn btn-primary me-2">Tampilkan</button>
            <a href="laporan_penjualan.php" class="btn btn-outline-secondary">Reset</a>
        </div>
    </form>

    <!-- RINGKASAN -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h6 class="text-muted">Total Pesanan Lunas</h6>
                    <h3 class="fw-bold"><?= $jumlahPesanan; ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h6 class="text-muted">Total Omzet</h6>
                    <h3 class="fw-bold">Rp <?= number_format($totalOmzet, 0, ',', '.'); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h6 class="text-muted">Rata-rata per Pesanan</h6>
                    <h3 class="fw-bold">Rp <?= number_format($rata2, 0, ',', '.'); ?></h3>
                </div>
            </div>
        </div>
    </div>

    <!-- TABEL PESANAN -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h5 class="mb-3">Daftar Pesanan (Lunas)</h5>
            <div class="table-responsive">
                <table class="table table-sm table-bordered align-middle">
                    <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Nama</th>
                        <th>Total</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if ($jumlahPesanan === 0): ?>
                        <tr>
                            <td colspan="4" class="text-center text-muted">
                                Belum ada pesanan lunas pada periode ini.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php $no = 1; foreach ($pesananData as $p): ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= htmlspecialchars($p['tanggal_pesanan']); ?></td>
                                <td><?= htmlspecialchars($p['nama_pelanggan']); ?></td>
                                <td>Rp <?= number_format($p['total'], 0, ',', '.'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- PRODUK TERLARIS -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h5 class="mb-3">Produk Terlaris</h5>
            <div class="table-responsive">
                <table class="table table-sm table-bordered align-middle">
                    <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Nama Produk</th>
                        <th>Jumlah Terjual</th>
                        <th>Omzet</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $no = 1;
                    if (mysqli_num_rows($topProduk) === 0): ?>
                        <tr>
                            <td colspan="4" class="text-center text-muted">
                                Belum ada penjualan pada periode ini.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php while ($row = mysqli_fetch_assoc($topProduk)): ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= htmlspecialchars($row['nama_produk']); ?></td>
                                <td><?= $row['total_jumlah']; ?></td>
                                <td>Rp <?= number_format($row['total_omzet'], 0, ',', '.'); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        crossorigin="anonymous"></script>
</body>
</html>
