<?php
include '../koneksi.php';

$id = $_POST['id'];
$nama = $_POST['nama_produk'];
$harga = $_POST['harga'];
$deskripsi = $_POST['deskripsi'];

if($_FILES['gambar']['name'] != ""){
    $gambar = $_FILES['gambar']['name'];
    move_uploaded_file($_FILES['gambar']['tmp_name'], "../gambar/".$gambar);
    mysqli_query($koneksi, "UPDATE produk SET nama_produk='$nama', harga='$harga', deskripsi='$deskripsi', gambar='$gambar' WHERE id_produk='$id'");
} else {
    mysqli_query($koneksi, "UPDATE produk SET nama_produk='$nama', harga='$harga', deskripsi='$deskripsi' WHERE id_produk='$id'");
}

header("location:daftar_produk.php");
?>
