<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
include 'koneksi.php';

// Batasi hanya admin
if (!isset($_SESSION['level']) || $_SESSION['level'] != 'admin') {
    echo "<script>alert('Akses ditolak! Anda bukan admin.');window.location='login.php';</script>";
    exit;
}

// PROSES SIMPAN PRODUK
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama       = trim($_POST['nama_produk'] ?? '');
    $hargaInput = trim($_POST['harga'] ?? '');
    $stok       = (int)($_POST['stok'] ?? 0);
    $deskripsi  = trim($_POST['deskripsi'] ?? '');

    // hapus format Rp dan titik
    $hargaInput = str_replace(['Rp', 'rp', '.', ' '], '', $hargaInput);
    $harga      = (float)$hargaInput;

    // validasi sederhana
    if ($nama === '' || $harga <= 0 || $stok < 0) {
        $error = 'Nama, harga, dan stok harus diisi dengan benar.';
    } else {
        // handle upload gambar
        $namaFileBaru = null;
        if (!empty($_FILES['gambar']['name'])) {
            $folderUpload = 'admin/upload/';
            if (!is_dir($folderUpload)) {
                mkdir($folderUpload, 0777, true);
            }

            $namaAsli = $_FILES['gambar']['name'];
            $tmp      = $_FILES['gambar']['tmp_name'];

            $extValid = ['jpg', 'jpeg', 'png', 'gif', 'bmp'];
            $ext      = strtolower(pathinfo($namaAsli, PATHINFO_EXTENSION));

            // Periksa apakah ekstensi file valid
            if (!in_array($ext, $extValid)) {
                $error = 'Format gambar harus JPG, JPEG, PNG, GIF, atau BMP.';
            } else {
                // Beri nama file yang unik
                $namaFileBaru = time() . '_' . rand(1000, 9999) . '.' . $ext;
                $tujuan       = $folderUpload . $namaFileBaru;

                // Pindahkan file ke folder upload
                if (!move_uploaded_file($tmp, $tujuan)) {
                    $error = 'Gagal mengupload gambar.';
                }
            }
        }

        // jika tidak ada error upload, insert ke database
        if (!isset($error)) {
            // asumsi tabel produk punya kolom: nama_produk, harga, stok, deskripsi, gambar
            $sql = "INSERT INTO produk (nama_produk, harga, stok, deskripsi, gambar)
                    VALUES (?,?,?,?,?)";
            $stmt = mysqli_prepare($koneksi, $sql);
            if ($stmt === false) {
                die('Query preparation failed: ' . mysqli_error($koneksi));
            }

            mysqli_stmt_bind_param($stmt, 'sdiss',
                $nama,
                $harga,
                $stok,
                $deskripsi,
                $namaFileBaru
            );

            // Eksekusi query dan cek hasilnya
            if (mysqli_stmt_execute($stmt)) {
                echo "<script>alert('Produk berhasil ditambahkan');window.location='halamanutama.php';</script>";
                exit;
            } else {
                $error = 'Gagal menyimpan produk ke database.';
            }
        }
    }
}
?>

<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Tambah Produk - Admin Morry48</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet" crossorigin="anonymous">
    <style>
        body { background-color: #f5f5f5; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark bg-dark px-4">
    <a class="navbar-brand fw-bold" href="halamanutama.php">Dashboard Admin Morry48</a>
</nav>

<div class="container my-4">
    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card shadow-sm">
                <div class="card-body">
                    <h3 class="mb-3">Tambah Produk Baru</h3>

                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($error); ?></div>
                    <?php endif; ?>

                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label class="form-label">Nama Produk</label>
                            <input type="text" name="nama_produk" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Harga</label>
                            <div class="input-group">
                                <span class="input-group-text">Rp</span>
                                <input type="text" name="harga" class="form-control"
                                       placeholder="contoh: 12000" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Stok</label>
                            <input type="number" name="stok" class="form-control" min="0" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Deskripsi</label>
                            <textarea name="deskripsi" class="form-control" rows="3"
                                      placeholder="Opsional"></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Gambar Produk</label>
                            <input type="file" name="gambar" class="form-control" required>
                            <div class="form-text">
                                Format yang diizinkan: JPG, JPEG, PNG, GIF, BMP.
                            </div>
                        </div>

                        <div class="d-flex justify-content-between">
                            <a href="halamanutama.php" class="btn btn-outline-secondary">
                                Kembali ke Dashboard
                            </a>
                            <button type="submit" class="btn btn-primary">
                                Simpan Produk
                            </button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        crossorigin="anonymous"></script>
</body>
</html>
