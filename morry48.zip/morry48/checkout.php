<?php
session_start();
include 'koneksi.php';

// Wajib login
if (!isset($_SESSION['id_user'])) {
    header('Location: login.php');
    exit;
}

// Pastikan keranjang ada isinya
if (!isset($_SESSION['keranjang']) || empty($_SESSION['keranjang'])) {
    header('Location: keranjang.php');
    exit;
}

// Susun data keranjang + hitung total
$detailKeranjang = [];
$total = 0;

foreach ($_SESSION['keranjang'] as $id_produk => $jumlah) {
    $id_produk = (int)$id_produk;
    $jumlah    = (int)$jumlah;

    if ($jumlah <= 0) continue;

    $qProduk = mysqli_query($koneksi, "SELECT * FROM produk WHERE id_produk = $id_produk");
    $produk  = mysqli_fetch_assoc($qProduk);
    if (!$produk) continue;

    $subtotal = $produk['harga'] * $jumlah;
    $total   += $subtotal;

    $detailKeranjang[] = [
        'id_produk'   => $id_produk,
        'nama_produk' => $produk['nama_produk'],
        'harga'       => $produk['harga'],
        'jumlah'      => $jumlah,
        'subtotal'    => $subtotal,
    ];
}

if ($total <= 0 || empty($detailKeranjang)) {
    header('Location: keranjang.php');
    exit;
}

// Ambil error kalau ada
$error = '';
if (isset($_SESSION['error_checkout'])) {
    $error = $_SESSION['error_checkout'];
    unset($_SESSION['error_checkout']);
}
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Checkout Pesanan - Morry48 Store</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet"
          integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
          crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4">
    <a class="navbar-brand fw-bold" href="index.php">Morry48 Store</a>
</nav>

<div class="container mt-4">
    <h2 class="mb-4">Checkout Pesanan</h2>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <div class="row">
        <!-- Data Pelanggan -->
        <div class="col-md-6">
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h4 class="card-title mb-3">Data Pelanggan</h4>
                    <form action="proses_checkout.php" method="post">
                        <div class="mb-3">
                            <label class="form-label">Nama Lengkap</label>
                            <input type="text" name="nama_pelanggan" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Alamat Pengiriman</label>
                            <textarea name="alamat" class="form-control" rows="4" required></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Nomor Telepon (opsional)</label>
                            <input type="text" name="telepon" class="form-control">
                        </div>

                        <button type="submit" class="btn btn-success">
                            Proses Checkout
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Ringkasan Pesanan -->
        <div class="col-md-6">
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h4 class="card-title mb-3">Ringkasan Pesanan</h4>

                    <table class="table table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th>No</th>
                                <th>Nama Produk</th>
                                <th>Harga</th>
                                <th>Jumlah</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $no = 1; foreach ($detailKeranjang as $item): ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= htmlspecialchars($item['nama_produk']); ?></td>
                                <td>Rp <?= number_format($item['harga'], 0, ',', '.'); ?></td>
                                <td><?= $item['jumlah']; ?></td>
                                <td>Rp <?= number_format($item['subtotal'], 0, ',', '.'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                            <tr>
                                <th colspan="4" class="text-end">Total</th>
                                <th>Rp <?= number_format($total, 0, ',', '.'); ?></th>
                            </tr>
                        </tbody>
                    </table>

                    <div class="alert alert-info">
                        Setelah klik <strong>Proses Checkout</strong>, pesanan akan tercatat
                        dengan status <strong>Menunggu Pembayaran</strong> &
                        <strong>Belum Dikirim</strong>.  
                        Kamu bisa upload bukti transfer dan cek status pengiriman di menu
                        <strong>Pesanan Saya</strong>.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</body>
</html>
