<?php
session_start();
include 'koneksi.php';

// Wajib login
if (!isset($_SESSION['id_user'])) {
    header('Location: login.php');
    exit;
}

// Pastikan keranjang terisi
if (!isset($_SESSION['keranjang']) || empty($_SESSION['keranjang'])) {
    header('Location: keranjang.php');
    exit;
}

// Wajib metode POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: checkout.php');
    exit;
}

// Ambil data form
$nama    = trim($_POST['nama_pelanggan'] ?? '');
$email   = trim($_POST['email'] ?? '');
$alamat  = trim($_POST['alamat'] ?? '');
$telepon = trim($_POST['telepon'] ?? ''); // belum disimpan di tabel pesanan

if ($nama === '' || $email === '' || $alamat === '') {
    $_SESSION['error_checkout'] = 'Mohon lengkapi data pelanggan.';
    header('Location: checkout.php');
    exit;
}

$id_user = (int)$_SESSION['id_user'];

// Hitung ulang total + siapkan data detail
$detailKeranjang = [];
$total = 0;

foreach ($_SESSION['keranjang'] as $id_produk => $jumlah) {
    $id_produk = (int)$id_produk;
    $jumlah    = (int)$jumlah;

    if ($jumlah <= 0) continue;

    $qProduk = mysqli_query($koneksi, "SELECT * FROM produk WHERE id_produk = $id_produk");
    $produk  = mysqli_fetch_assoc($qProduk);
    if (!$produk) continue;

    $subtotal = $produk['harga'] * $jumlah;
    $total   += $subtotal;

    $detailKeranjang[] = [
        'id_produk'   => $id_produk,
        'nama_produk' => $produk['nama_produk'],
        'harga'       => (float)$produk['harga'],
        'jumlah'      => $jumlah
        // subtotal hanya dipakai untuk tampilan, tidak disimpan di tabel
    ];
}

if ($total <= 0 || empty($detailKeranjang)) {
    $_SESSION['error_checkout'] = 'Keranjang kosong atau produk tidak valid.';
    header('Location: keranjang.php');
    exit;
}

// Status awal
$statusPembayaran = 'Menunggu Pembayaran';
$statusPengiriman = 'Belum Dikirim';

// Insert ke tabel pesanan
$sqlPesanan = "INSERT INTO pesanan
    (nama_pelanggan, email, alamat, total, id_user, status_Pembayaran, status_pengiriman)
    VALUES (?,?,?,?,?,?,?)";

$stmt = mysqli_prepare($koneksi, $sqlPesanan);

if (!$stmt) {
    die('Query pesanan error: ' . mysqli_error($koneksi));
}

mysqli_stmt_bind_param(
    $stmt,
    'sssdiss', // nama, email, alamat, total, id_user, statusPembayaran, statusPengiriman
    $nama,
    $email,
    $alamat,
    $total,
    $id_user,
    $statusPembayaran,
    $statusPengiriman
);

mysqli_stmt_execute($stmt);

$id_pesanan = mysqli_insert_id($koneksi);

// Insert ke detail_pesanan
$sqlDetail = "INSERT INTO detail_pesanan
    (id_pesanan, id_produk, nama_produk, harga, jumlah)
    VALUES (?,?,?,?,?)";

$stmtDetail = mysqli_prepare($koneksi, $sqlDetail);

if (!$stmtDetail) {
    die('Query detail error: ' . mysqli_error($koneksi));
}

foreach ($detailKeranjang as $item) {
    $idProd   = $item['id_produk'];
    $namaProd = $item['nama_produk'];
    $harga    = $item['harga'];
    $jumlah   = $item['jumlah'];

    mysqli_stmt_bind_param(
        $stmtDetail,
        'iisdi',                // i: id_pesanan, i: idProd, s: namaProd, d: harga, i: jumlah
        $id_pesanan,
        $idProd,
        $namaProd,
        $harga,
        $jumlah
    );
    mysqli_stmt_execute($stmtDetail);
}

// Kosongkan keranjang
unset($_SESSION['keranjang']);

// (opsional) telepon bisa disimpan di tabel user/terpisah kalau mau

// Redirect ke halaman pesanan saya
header('Location: pesanan_saya.php');
exit;
