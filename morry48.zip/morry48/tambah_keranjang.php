<?php
session_start();
include 'koneksi.php';

// WAJIB LOGIN (kalau mau tanpa login, hapus blok ini)
if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit;
}

// validasi id
if (!isset($_GET['id']) || !ctype_digit($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = (int) $_GET['id'];

// ambil produk
$stmt = mysqli_prepare($koneksi, "SELECT id_produk, nama_produk, harga, gambar, stok FROM produk WHERE id_produk = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($res);

if (!$data) {
    die("Produk tidak ditemukan.");
}

// siapkan session keranjang
if (!isset($_SESSION['keranjang']) || !is_array($_SESSION['keranjang'])) {
    $_SESSION['keranjang'] = [];
}

// jika belum ada itemnya
if (!isset($_SESSION['keranjang'][$id])) {
    $_SESSION['keranjang'][$id] = [
        'nama'   => $data['nama_produk'],
        'harga'  => (int)$data['harga'],
        'jumlah' => 1,
        'gambar' => $data['gambar']
    ];
} else {
    $_SESSION['keranjang'][$id]['jumlah']++;
}

// redirect ke keranjang
header("Location: keranjang.php");
exit;
