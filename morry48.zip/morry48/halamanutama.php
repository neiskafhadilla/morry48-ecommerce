<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
include 'koneksi.php';

// Batasi hanya admin
if (!isset($_SESSION['level']) || $_SESSION['level'] != 'admin') {
    echo "<script>alert('Akses ditolak! Anda bukan admin.');window.location='login.php';</script>";
    exit;
}

$flash_message = '';

// Daftar nilai status yang diizinkan
$allowedStatusBayar = ['', 'Menunggu Pembayaran', 'Menunggu Konfirmasi', 'Lunas', 'Ditolak'];
$allowedStatusKirim = ['', 'Belum Dikirim', 'Dikirim', 'Sampai'];

// =====================
// UPDATE PESANAN (inline)
// =====================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_pesanan'])) {
    $id_pesanan       = (int)$_POST['id_pesanan'];
    $statusPembayaran = $_POST['status_Pembayaran'] ?? 'Menunggu Pembayaran';
    $statusPengiriman = $_POST['status_pengiriman'] ?? 'Belum Dikirim';
    $resi             = trim($_POST['resi_pengiriman'] ?? '');

    if (!in_array($statusPembayaran, $allowedStatusBayar)) {
        $statusPembayaran = 'Menunggu Pembayaran';
    }
    if (!in_array($statusPengiriman, $allowedStatusKirim)) {
        $statusPengiriman = 'Belum Dikirim';
    }

    // Ambil status pembayaran lama untuk cek kapan berubah jadi "Lunas"
    $oldRes = mysqli_query($koneksi, "SELECT status_Pembayaran FROM pesanan WHERE id_pesanan = $id_pesanan");
    $oldRow = mysqli_fetch_assoc($oldRes);
    $oldStatusBayar = $oldRow ? $oldRow['status_Pembayaran'] : '';

    $ubahKeLunas = ($statusPembayaran === 'Lunas' && $oldStatusBayar !== 'Lunas');

    // Menyiapkan query update pesanan
    $stmt = mysqli_prepare(
        $koneksi,
        "UPDATE pesanan SET status_Pembayaran = ?, status_pengiriman = ?, resi_pengiriman = ? WHERE id_pesanan = ?"
    );

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'sssi', $statusPembayaran, $statusPengiriman, $resi, $id_pesanan);
        mysqli_stmt_execute($stmt);

        // Kalau baru pertama kali dinyatakan Lunas → kurangi stok produk
        if ($ubahKeLunas) {
            $detail = mysqli_query(
                $koneksi,
                "SELECT id_produk, jumlah FROM detail_pesanan WHERE id_pesanan = $id_pesanan"
            );
            while ($d = mysqli_fetch_assoc($detail)) {
                $idProd = (int)$d['id_produk'];
                $qty    = (int)$d['jumlah'];
                if ($qty > 0) {
                    mysqli_query(
                        $koneksi,
                        "UPDATE produk 
                         SET stok = GREATEST(stok - $qty, 0) 
                         WHERE id_produk = $idProd"
                    );
                }
            }
        }

        $flash_message = "Pesanan #{$id_pesanan} berhasil diperbarui.";
    } else {
        $flash_message = 'Gagal update pesanan: ' . mysqli_error($koneksi);
    }
}

// =====================
// RINGKASAN
// =====================
$totalPesanan = mysqli_fetch_row(
    mysqli_query($koneksi, "SELECT COUNT(*) FROM pesanan")
)[0];

$menungguBayar = mysqli_fetch_row(
    mysqli_query($koneksi, "SELECT COUNT(*) FROM pesanan 
                            WHERE status_Pembayaran IN ('Menunggu Pembayaran','Menunggu Konfirmasi')")
)[0];

$belumDikirim = mysqli_fetch_row(
    mysqli_query($koneksi, "SELECT COUNT(*) FROM pesanan 
                            WHERE status_pengiriman = 'Belum Dikirim'")
)[0];

// =====================
// FILTER PESANAN (GET)
// =====================
$statusFilter = $_GET['status_bayar'] ?? '';
$kirimFilter  = $_GET['status_kirim'] ?? '';

if (!in_array($statusFilter, $allowedStatusBayar)) $statusFilter = '';
if (!in_array($kirimFilter, $allowedStatusKirim))  $kirimFilter  = '';

$whereParts = [];
if ($statusFilter !== '') {
    $esc = mysqli_real_escape_string($koneksi, $statusFilter);
    $whereParts[] = "status_Pembayaran = '$esc'";
}
if ($kirimFilter !== '') {
    $esc = mysqli_real_escape_string($koneksi, $kirimFilter);
    $whereParts[] = "status_pengiriman = '$esc'";
}
$whereClause = $whereParts ? 'WHERE ' . implode(' AND ', $whereParts) : '';

// =====================
// DATA TABEL
// =====================
$pesanan = mysqli_query($koneksi, "SELECT * FROM pesanan $whereClause ORDER BY tanggal_pesanan DESC LIMIT 50");
$produk  = mysqli_query($koneksi, "SELECT * FROM produk ORDER BY id_produk ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Dashboard Admin Morry48</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet" crossorigin="anonymous">
    <style>
        body { background-color: #f5f5f5; }
        .card-summary { min-height: 100px; }
        .table img { max-height: 70px; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark bg-dark px-4">
    <a class="navbar-brand fw-bold" href="halamanutama.php">Dashboard Admin Morry48</a>
    <div class="d-flex">
        <a href="laporan_penjualan.php" class="btn btn-outline-light btn-sm me-2">Laporan Penjualan</a>
        <a href="index.php" class="btn btn-outline-light btn-sm me-2">Lihat Toko</a>
        <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
    </div>
</nav>

<div class="container my-4">

    <?php if ($flash_message): ?>
        <div class="alert alert-info"><?= htmlspecialchars($flash_message); ?></div>
    <?php endif; ?>

    <!-- RINGKASAN -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card card-summary shadow-sm border-0">
                <div class="card-body">
                    <h6 class="text-muted">Total Pesanan</h6>
                    <h3 class="fw-bold"><?= $totalPesanan; ?></h3>
                    <small class="text-muted">Semua pesanan yang pernah masuk</small>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-summary shadow-sm border-0">
                <div class="card-body">
                    <h6 class="text-muted">Menunggu Pembayaran/Konfirmasi</h6>
                    <h3 class="fw-bold"><?= $menungguBayar; ?></h3>
                    <small class="text-muted">Butuh dicek & dikonfirmasi</small>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-summary shadow-sm border-0">
                <div class="card-body">
                    <h6 class="text-muted">Belum Dikirim</h6>
                    <h3 class="fw-bold"><?= $belumDikirim; ?></h3>
                    <small class="text-muted">Pesanan yang siap dikirim</small>
                </div>
            </div>
        </div>
    </div>

    <!-- TAB -->
    <ul class="nav nav-tabs mb-3" id="adminTab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="pesanan-tab" data-bs-toggle="tab"
                    data-bs-target="#pesanan" type="button" role="tab">
                Pesanan
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="produk-tab" data-bs-toggle="tab"
                    data-bs-target="#produk" type="button" role="tab">
                Produk
            </button>
        </li>
    </ul>

    <div class="tab-content" id="adminTabContent">

        <!-- TAB PESANAN -->
        <div class="tab-pane fade show active" id="pesanan" role="tabpanel"
             aria-labelledby="pesanan-tab">
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h5 class="mb-3">Pesanan Terbaru</h5>

                    <!-- FILTER -->
                    <form method="get" class="row g-2 mb-3">
                        <div class="col-md-3">
                            <label class="form-label mb-1">Status Pembayaran</label>
                            <select name="status_bayar" class="form-select form-select-sm">
                                <option value="">Semua</option>
                                <?php foreach (array_slice($allowedStatusBayar, 1) as $s): ?>
                                    <option value="<?= $s; ?>" <?= $statusFilter == $s ? 'selected' : ''; ?>>
                                        <?= $s; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label mb-1">Status Pengiriman</label>
                            <select name="status_kirim" class="form-select form-select-sm">
                                <option value="">Semua</option>
                                <?php foreach (array_slice($allowedStatusKirim, 1) as $s): ?>
                                    <option value="<?= $s; ?>" <?= $kirimFilter == $s ? 'selected' : ''; ?>>
                                        <?= $s; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary btn-sm me-2">Filter</button>
                            <a href="halamanutama.php" class="btn btn-outline-secondary btn-sm">Reset</a>
                        </div>
                    </form>

                    <div class="table-responsive">
                        <table class="table table-sm table-bordered align-middle">
                            <thead class="table-dark">
                            <tr>
                                <th>No</th>
                                <th>Tanggal</th>
                                <th>Nama</th>
                                <th>Total</th>
                                <th>Status Pembayaran</th>
                                <th>Status Pengiriman</th>
                                <th>Resi</th>
                                <th>Bukti</th>
                                <th>Aksi</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $no = 1; while ($row = mysqli_fetch_assoc($pesanan)) : ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td><?= htmlspecialchars($row['tanggal_pesanan']); ?></td>
                                    <td><?= htmlspecialchars($row['nama_pelanggan']); ?></td>
                                    <td>Rp <?= number_format($row['total'], 0, ',', '.'); ?></td>
                                    <td><?= htmlspecialchars($row['status_Pembayaran']); ?></td>
                                    <td><?= htmlspecialchars($row['status_pengiriman']); ?></td>
                                    <td><?= htmlspecialchars($row['resi_pengiriman']); ?></td>
                                    <td>
                                        <?php if (!empty($row['bukti_Transfer'])): ?>
                                            <a href="upload/bukti_transfer/<?= htmlspecialchars($row['bukti_Transfer']); ?>"
                                               target="_blank" class="btn btn-sm btn-outline-primary">Lihat</a>
                                        <?php else: ?>
                                            <span class="text-muted small">Tidak ada</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <form method="post" class="d-flex gap-1">
                                            <input type="hidden" name="id_pesanan" value="<?= $row['id_pesanan']; ?>">
                                            <select name="status_Pembayaran" class="form-select form-select-sm">
                                                <?php
                                                foreach (array_slice($allowedStatusBayar, 1) as $s) {
                                                    $sel = ($s == $row['status_Pembayaran']) ? 'selected' : '';
                                                    echo "<option value=\"$s\" $sel>$s</option>";
                                                }
                                                ?>
                                            </select>
                                            <select name="status_pengiriman" class="form-select form-select-sm">
                                                <?php
                                                foreach (array_slice($allowedStatusKirim, 1) as $s) {
                                                    $sel = ($s == $row['status_pengiriman']) ? 'selected' : '';
                                                    echo "<option value=\"$s\" $sel>$s</option>";
                                                }
                                                ?>
                                            </select>
                                            <input type="text" name="resi_pengiriman" class="form-control form-control-sm"
                                                   value="<?= htmlspecialchars($row['resi_pengiriman']); ?>" placeholder="No. Resi">
                                            <button type="submit" name="update_pesanan" value="1" class="btn btn-sm btn-success">Simpan</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                            <?php if ($no === 1): ?>
                                <tr>
                                    <td colspan="9" class="text-center text-muted">Belum ada pesanan.</td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- TAB PRODUK -->
        <div class="tab-pane fade" id="produk" role="tabpanel" aria-labelledby="produk-tab">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="mb-0">Kelola Produk</h5>
                        <a href="tambah_produk.php" class="btn btn-sm btn-primary">+ Tambah Produk</a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered align-middle">
                            <thead class="table-dark">
                            <tr>
                                <th>ID</th>
                                <th>Nama Produk</th>
                                <th>Harga</th>
                                <th>Stok</th>
                                <th>Gambar</th>
                                <th>Aksi</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php while ($row = mysqli_fetch_assoc($produk)) : ?>
                                <tr>
                                    <td><?= $row['id_produk']; ?></td>
                                    <td><?= htmlspecialchars($row['nama_produk']); ?></td>
                                    <td>Rp <?= number_format($row['harga'], 0, ',', '.'); ?></td>
                                    <td><?= $row['stok']; ?></td>
                                    <td>
                                        <?php if (!empty($row['gambar'])): ?>
                                            <img src="admin/upload/<?= htmlspecialchars($row['gambar']); ?>" alt=""
                                                 class="img-fluid">
                                        <?php else: ?>
                                            <span class="text-muted small">Tidak ada</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="white-space: nowrap;">
                                        <a href="edit_produk.php?id=<?= $row['id_produk']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                        <a href="hapus_produk.php?id=<?= $row['id_produk']; ?>"
                                           class="btn btn-sm btn-danger"
                                           onclick="return confirm('Yakin ingin menghapus produk ini?');">Hapus</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <small class="text-muted">Produk di sini akan muncul di halaman utama Morry48 Store.</small>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>
