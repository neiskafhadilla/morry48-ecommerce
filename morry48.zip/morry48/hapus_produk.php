<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
include 'koneksi.php';

// pastikan hanya admin
if (!isset($_SESSION['level']) || $_SESSION['level'] != 'admin') {
    echo "<script>alert('Akses ditolak! Anda bukan admin.');window.location='login.php';</script>";
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: halamanutama.php');
    exit;
}

$id = (int) $_GET['id'];

// ambil data produk dulu untuk tahu nama file gambar
$q = mysqli_query($koneksi, "SELECT * FROM produk WHERE id_produk = $id");
$produk = mysqli_fetch_assoc($q);

if ($produk) {
    // hapus record di database
    mysqli_query($koneksi, "DELETE FROM produk WHERE id_produk = $id");

    // hapus file gambar kalau ada
    if (!empty($produk['gambar'])) {
        $path = __DIR__ . '/admin/upload/' . $produk['gambar'];
        if (file_exists($path)) {
            unlink($path);
        }
    }
}

header('Location: halamanutama.php');
exit;
