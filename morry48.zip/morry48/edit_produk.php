<?php
session_start();
include 'koneksi.php';

// Hanya admin yang boleh akses halaman ini
if (!isset($_SESSION['level']) || $_SESSION['level'] != 'admin') {
    echo "<script>alert('Akses ditolak!');window.location='login.php';</script>";
    exit;
}

// Ambil data produk yang ingin diedit berdasarkan id_produk
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id_produk = (int)$_GET['id'];
    $result = mysqli_query($koneksi, "SELECT * FROM produk WHERE id_produk = $id_produk");
    $produk = mysqli_fetch_assoc($result);

    if (!$produk) {
        echo "<script>alert('Produk tidak ditemukan.');window.location='halamanutama.php';</script>";
        exit;
    }
} else {
    echo "<script>alert('ID Produk tidak valid.');window.location='halamanutama.php';</script>";
    exit;
}

// Proses ketika form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_produk = mysqli_real_escape_string($koneksi, $_POST['nama_produk']);
    $harga = mysqli_real_escape_string($koneksi, $_POST['harga']);
    $stok = mysqli_real_escape_string($koneksi, $_POST['stok']);
    $deskripsi = mysqli_real_escape_string($koneksi, $_POST['deskripsi']);
    $gambar_baru = $_FILES['gambar']['name'];
    $gambar_lama = $produk['gambar']; // Simpan gambar lama jika tidak ada gambar baru

    // Validasi input
    if (empty($nama_produk) || empty($harga) || empty($stok)) {
        echo "<script>alert('Semua kolom harus diisi.');</script>";
    } else {
        // Jika ada gambar baru
        if ($gambar_baru) {
            $target_dir = "admin/upload/";
            $target_file = $target_dir . basename($gambar_baru);
            if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target_file)) {
                // Hapus gambar lama
                if ($gambar_lama && file_exists($target_dir . $gambar_lama)) {
                    unlink($target_dir . $gambar_lama);
                }
            }
        } else {
            // Jika tidak ada gambar baru, gunakan gambar lama
            $gambar_baru = $gambar_lama;
        }

        // Update data produk
        $update_query = "UPDATE produk SET 
                            nama_produk = '$nama_produk',
                            harga = '$harga',
                            stok = '$stok',
                            deskripsi = '$deskripsi',
                            gambar = '$gambar_baru'
                          WHERE id_produk = $id_produk";
        $update_result = mysqli_query($koneksi, $update_query);

        if ($update_result) {
            echo "<script>alert('Produk berhasil diperbarui.');window.location='halamanutama.php';</script>";
        } else {
            echo "<script>alert('Gagal memperbarui produk.');</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Produk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet" crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 800px;
        }
    </style>
</head>
<body>

<div class="container my-4">
    <h2 class="mb-4 text-center">Edit Produk</h2>
    <a href="halamanutama.php" class="btn btn-secondary mb-3">&lt; Kembali ke Dashboard</a>

    <!-- Form Edit Produk -->
    <form action="edit_produk.php?id=<?= $produk['id_produk']; ?>" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="nama_produk" class="form-label">Nama Produk</label>
            <input type="text" class="form-control" id="nama_produk" name="nama_produk" value="<?= htmlspecialchars($produk['nama_produk']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="harga" class="form-label">Harga</label>
            <input type="number" class="form-control" id="harga" name="harga" value="<?= htmlspecialchars($produk['harga']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="stok" class="form-label">Stok</label>
            <input type="number" class="form-control" id="stok" name="stok" value="<?= htmlspecialchars($produk['stok']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="deskripsi" class="form-label">Deskripsi</label>
            <textarea class="form-control" id="deskripsi" name="deskripsi" rows="4" required><?= htmlspecialchars($produk['deskripsi']); ?></textarea>
        </div>

        <div class="mb-3">
            <label for="gambar" class="form-label">Gambar Saat Ini</label><br>
            <img src="admin/upload/<?= htmlspecialchars($produk['gambar']); ?>" alt="Gambar Produk" style="max-height: 150px; max-width: 150px; object-fit: contain;">
        </div>
        <div class="mb-3">
            <label for="gambar" class="form-label">Ganti Gambar (optional)</label>
            <input type="file" class="form-control" id="gambar" name="gambar">
        </div>

        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        crossorigin="anonymous"></script>
</body>
</html>
