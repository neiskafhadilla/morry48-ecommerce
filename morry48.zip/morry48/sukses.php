<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Pembelian Sukses - Morry48</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center justify-content-center" style="height: 100vh;">

<div class="text-center">
  <div class="alert alert-success shadow-lg p-5">
    <h2>✅ Pesanan Berhasil!</h2>
    <p>Terima kasih telah berbelanja di Morry48 Store.</p>
    <a href="index.php" class="btn btn-primary mt-3">Kembali ke Beranda</a>
  </div>
</div>

</body>
</html>
