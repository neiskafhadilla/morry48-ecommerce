<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['id_user'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_user    = $_SESSION['id_user'];
    $id_pesanan = (int)$_POST['id_pesanan'];

    // cek pesanan milik user
    $cek = mysqli_prepare($koneksi,
        "SELECT id_pesanan FROM pesanan WHERE id_pesanan = ? AND id_user = ?");
    mysqli_stmt_bind_param($cek, 'ii', $id_pesanan, $id_user);
    mysqli_stmt_execute($cek);
    $res = mysqli_stmt_get_result($cek);
    if ($res->num_rows == 0) {
        die("Pesanan tidak valid.");
    }

    // folder upload
    $folder = 'upload/bukti_transfer/';
    if (!is_dir($folder)) {
        mkdir($folder, 0777, true);
    }

    // validasi file sederhana
    $allowed = ['jpg','jpeg','png','pdf'];
    $namaAsli = $_FILES['bukti']['name'];
    $tmp      = $_FILES['bukti']['tmp_name'];

    $ext = strtolower(pathinfo($namaAsli, PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) {
        die("Tipe file tidak diizinkan.");
    }

    $namaBaru = time() . '_' . rand(1000,9999) . '.' . $ext;
    $tujuan   = $folder . $namaBaru;

    if (move_uploaded_file($tmp, $tujuan)) {
        // update pesanan: simpan nama file & ubah status pembayaran
        $upd = mysqli_prepare($koneksi,
            "UPDATE pesanan 
             SET bukti_Transfer = ?, status_Pembayaran = 'Menunggu Konfirmasi'
             WHERE id_pesanan = ?");
        mysqli_stmt_bind_param($upd, 'si', $namaBaru, $id_pesanan);
        mysqli_stmt_execute($upd);

        header("Location: pesanan_saya.php");
        exit;
    } else {
        echo "Gagal upload file.";
    }
}
