<?php
session_start();
include 'koneksi.php';

// Pastikan session keranjang valid
if (!isset($_SESSION['keranjang']) || !is_array($_SESSION['keranjang'])) {
    $_SESSION['keranjang'] = [];
}

/* =========================
   ADD DARI HALAMAN PRODUK
========================= */
if (isset($_GET['add'])) {
    $id_produk = (int)$_GET['add'];

    $sql = "SELECT * FROM produk WHERE id_produk = ?";
    $stmt = mysqli_prepare($koneksi, $sql);
    mysqli_stmt_bind_param($stmt, 'i', $id_produk);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $produk = mysqli_fetch_assoc($result);

    if ($produk) {
        if (isset($_SESSION['keranjang'][$id_produk])) {
            $harga  = (int)($_SESSION['keranjang'][$id_produk]['harga'] ?? $produk['harga']);
            $jumlah = (int)($_SESSION['keranjang'][$id_produk]['jumlah'] ?? 0) + 1;

            $_SESSION['keranjang'][$id_produk] = [
                'nama_produk' => $_SESSION['keranjang'][$id_produk]['nama_produk'] ?? $produk['nama_produk'],
                'harga'       => $harga,
                'jumlah'      => $jumlah,
                'total'       => $harga * $jumlah,
            ];
        } else {
            $_SESSION['keranjang'][$id_produk] = [
                'nama_produk' => $produk['nama_produk'],
                'harga'       => (int)$produk['harga'],
                'jumlah'      => 1,
                'total'       => (int)$produk['harga'],
            ];
        }
    }
}

/* =========================
   FITUR + / -
========================= */
if (isset($_GET['inc'])) {
    $id_produk = (int)$_GET['inc'];
    if (isset($_SESSION['keranjang'][$id_produk])) {
        $harga = (int)($_SESSION['keranjang'][$id_produk]['harga'] ?? 0);
        $_SESSION['keranjang'][$id_produk]['jumlah'] = (int)($_SESSION['keranjang'][$id_produk]['jumlah'] ?? 0) + 1;
        $_SESSION['keranjang'][$id_produk]['total']  = $harga * $_SESSION['keranjang'][$id_produk]['jumlah'];
    }
}

if (isset($_GET['dec'])) {
    $id_produk = (int)$_GET['dec'];
    if (isset($_SESSION['keranjang'][$id_produk])) {
        $harga  = (int)($_SESSION['keranjang'][$id_produk]['harga'] ?? 0);
        $jumlah = (int)($_SESSION['keranjang'][$id_produk]['jumlah'] ?? 0) - 1;

        if ($jumlah <= 0) {
            unset($_SESSION['keranjang'][$id_produk]);
        } else {
            $_SESSION['keranjang'][$id_produk]['jumlah'] = $jumlah;
            $_SESSION['keranjang'][$id_produk]['total']  = $harga * $jumlah;
        }
    }
}

/* =========================
   HAPUS ITEM
========================= */
if (isset($_GET['hapus'])) {
    $id_produk = (int)$_GET['hapus'];
    if (isset($_SESSION['keranjang'][$id_produk])) {
        unset($_SESSION['keranjang'][$id_produk]);
    }
}

/* =========================
   NORMALISASI DATA (AMAN)
========================= */
$keranjang = $_SESSION['keranjang'];

foreach ($keranjang as $id => &$item) {
    if (!is_array($item)) $item = [];

    $item['nama_produk'] = $item['nama_produk'] ?? ($item['nama'] ?? '');
    $item['harga']       = (int)($item['harga'] ?? 0);
    $item['jumlah']      = (int)($item['jumlah'] ?? 0);
    $item['total']       = isset($item['total']) ? (int)$item['total'] : ($item['harga'] * $item['jumlah']);
}
unset($item);

$_SESSION['keranjang'] = $keranjang;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Keranjang Belanja</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container">
    <h2 class="my-4">Keranjang Belanja</h2>
    <table class="table table-bordered align-middle">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Produk</th>
                <th>Harga</th>
                <th style="width:180px;">Jumlah</th>
                <th>Total</th>
                <th style="width:90px;">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($keranjang)): ?>
                <?php $no = 1; $totalKeranjang = 0; ?>
                <?php foreach ($keranjang as $id_produk => $item): ?>
                    <?php
                        $nama   = $item['nama_produk'] !== '' ? $item['nama_produk'] : '-';
                        $harga  = (int)$item['harga'];
                        $jumlah = (int)$item['jumlah'];
                        $total  = (int)$item['total'];
                        $totalKeranjang += $total;
                    ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= htmlspecialchars($nama); ?></td>
                        <td>Rp <?= number_format($harga, 0, ',', '.'); ?></td>

                        <!-- Jumlah dengan tombol - dan + -->
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <a class="btn btn-outline-secondary btn-sm"
                                   href="keranjang.php?dec=<?= (int)$id_produk; ?>">−</a>

                                <span class="fw-bold"><?= $jumlah; ?></span>

                                <a class="btn btn-outline-secondary btn-sm"
                                   href="keranjang.php?inc=<?= (int)$id_produk; ?>">+</a>
                            </div>
                        </td>

                        <td>Rp <?= number_format($total, 0, ',', '.'); ?></td>
                        <td>
                            <a href="keranjang.php?hapus=<?= (int)$id_produk; ?>" class="btn btn-danger btn-sm">
                                Hapus
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>

                <tr>
                    <td colspan="4" class="text-end"><b>Total:</b></td>
                    <td><b>Rp <?= number_format($totalKeranjang, 0, ',', '.'); ?></b></td>
                    <td></td>
                </tr>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center">Keranjang kosong.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <a href="index.php" class="btn btn-secondary">Kembali ke Beranda</a>
    <a href="checkout.php" class="btn btn-primary">Lanjut ke Checkout</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
