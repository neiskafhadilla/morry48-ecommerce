<?php
session_start();

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['id_user'])) {
    echo "<script>alert('Silakan login terlebih dahulu untuk mengakses halaman ini.'); window.location='login.php';</script>";
    exit;
}

// Ambil data pengguna jika sudah login
$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cara Pembayaran - Morry48 Store</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            max-width: 900px;
        }
        .footer {
            text-align: center;
            padding: 15px;
            margin-top: 30px;
            background-color: #f8f9fa;
        }
    </style>
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4">
    <a class="navbar-brand fw-bold" href="index.php">Morry48 Store</a>
    <div class="d-flex align-items-center">
        <span class="text-white me-3">Hi, <?= htmlspecialchars($username); ?></span>
        <a href="keranjang.php" class="btn btn-outline-light me-3">Keranjang</a>
        <a href="logout.php" class="btn btn-outline-danger">Logout</a>
    </div>
</nav>

<!-- Halaman Cara Pembayaran -->
<div class="container mt-5">
    <h2 class="mb-4 text-center">Cara Pembayaran</h2>
    
    <p>Ikuti langkah-langkah berikut untuk melakukan pembayaran di Morry48 Store:</p>
    
    <ol>
        <li>Pilih produk dan masukkan ke keranjang, lalu lanjut ke <a href="keranjang.php">checkout</a>.</li>
        <li>Isi data diri dan alamat pengiriman, kemudian klik <strong>Proses Checkout</strong>. Pesanan akan tercatat dengan status <strong>Menunggu Pembayaran</strong>.</li>
        <li>Lakukan transfer pembayaran ke rekening toko:
            <ul>
                <li><strong>Bank</strong>: Bank Central Asia</li>
                <li><strong>No. Rekening</strong>: 49603922826</li>
                <li><strong>Atas Nama</strong>: PT Morry Indonesia</li>
            </ul>
        </li>
        <li>Setelah transfer, masuk ke menu <a href="pesanan_saya.php">Pesanan Saya</a>, pilih pesanan yang ingin dikonfirmasi, lalu klik <strong>Upload Bukti</strong> dan unggah foto/screenshot bukti transfer.</li>
        <li>Admin akan memeriksa pembayaran. Jika valid, status akan menjadi <strong>Lunas</strong> dan pesanan akan dikirim. Nomor resi bisa dilihat di halaman <a href="pesanan_saya.php">Pesanan Saya</a>.</li>
    </ol>

    <div class="alert alert-info">
        <strong>Informasi Penting:</strong>
        Ongkir ditanggung pembeli dan apabila paket sampai, sertakan video unboxing untuk retur apabila barang tidak lengkap atau rusak.
    </div>

    <!-- Button Kembali ke Beranda -->
    <div class="d-flex justify-content-center">
        <a href="index.php" class="btn btn-outline-primary">Kembali ke Beranda</a>
    </div>

    <footer class="footer mt-5">
        <h4>Kontak</h4>
        <p>Jika ada pertanyaan, hubungi:</p>
        <ul>
            <li>WhatsApp: 0895-4144-00480</li>
            <li>Email: Morry48@admin.com</li>
        </ul>
        <p>&copy; 2025 Morry48 Store | All Rights Reserved</p>
    </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
