<?php
session_start();
include 'koneksi.php';

// ========================
// SEARCH (AMAN - PREPARED)
// ========================
$searchQuery = '';
if (isset($_POST['search'])) {
    $searchQuery = trim($_POST['search']);
}

if ($searchQuery !== '') {
    $like = "%{$searchQuery}%";
    $stmt = mysqli_prepare($koneksi, "SELECT * FROM produk WHERE nama_produk LIKE ? ORDER BY id_produk ASC");
    mysqli_stmt_bind_param($stmt, "s", $like);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    $result = mysqli_query($koneksi, "SELECT * FROM produk ORDER BY id_produk ASC");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Morry48 Store</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        :root{
            --card-radius: 18px;
        }
        body{
            background: #f6f7fb;
        }
        .navbar{
            backdrop-filter: blur(10px);
        }
        .hero{
            padding: 38px 0 18px;
        }
        .hero h1{
            font-weight: 800;
            letter-spacing: -0.02em;
        }
        .hero p{
            color: #6c757d;
            margin-bottom: 0;
        }

        .search-wrap{
            max-width: 760px;
            margin: 0 auto;
        }
        .search-input{
            border-radius: 999px;
            padding: 12px 16px;
            border: 1px solid rgba(0,0,0,.08);
            box-shadow: 0 8px 24px rgba(17, 24, 39, 0.06);
        }
        .search-btn{
            border-radius: 999px;
            padding: 12px 18px;
            box-shadow: 0 8px 24px rgba(17, 24, 39, 0.10);
        }

        .product-card{
            border: 0;
            border-radius: var(--card-radius);
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(17, 24, 39, 0.08);
            transition: transform .15s ease, box-shadow .15s ease;
            height: 100%;
        }
        .product-card:hover{
            transform: translateY(-4px);
            box-shadow: 0 14px 36px rgba(17, 24, 39, 0.14);
        }
        .product-img-wrap{
            background: #fff;
            padding: 18px;
        }
        .product-img{
            width: 100%;
            height: 180px;
            object-fit: contain;
            border-radius: 12px;
            background: #ffffff;
        }
        .product-body{
            padding: 16px 16px 18px;
            background: #fff;
        }
        .product-title{
            font-weight: 700;
            margin-bottom: 6px;
            min-height: 44px; /* biar tinggi judul rata */
        }
        .product-price{
            font-weight: 800;
            color: #0d6efd;
            margin-bottom: 12px;
        }
        .btn-soft{
            border-radius: 12px;
        }

        .footer{
            color: #6c757d;
            padding: 28px 0;
            font-size: 14px;
        }

        /* dropdown style lebih clean */
        .dropdown-menu{
            border: 0;
            border-radius: 14px;
            box-shadow: 0 12px 30px rgba(17, 24, 39, 0.12);
            padding: 8px;
        }
        .dropdown-item{
            border-radius: 10px;
            padding: 10px 12px;
        }
    </style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4 py-3">
    <a class="navbar-brand fw-bold" href="index.php">Morry48 Store</a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navMain">
        <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2">
            <li class="nav-item">
                <a class="nav-link" href="keranjang.php">Keranjang</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="cara_pembayaran.php">Cara Pembayaran</a>
            </li>

            <!-- USER DROPDOWN -->
            <li class="nav-item dropdown">
                <button class="btn btn-outline-light btn-sm dropdown-toggle"
                        data-bs-toggle="dropdown" aria-expanded="false">
                    Hi, <?= isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'Guest'; ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <?php if (isset($_SESSION['id_user'])): ?>

                        <?php if (isset($_SESSION['level']) && $_SESSION['level'] === 'admin'): ?>
                            <!-- Penting: dashboard admin kamu itu halamanutama.php -->
                            <li><a class="dropdown-item" href="halamanutama.php">Admin Dashboard</a></li>
                        <?php endif; ?>

                        <li><a class="dropdown-item" href="pesanan_saya.php">Pesanan Saya</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php">Logout</a></li>

                    <?php else: ?>
                        <li><a class="dropdown-item" href="login.php">Login</a></li>
                        <li><a class="dropdown-item" href="daftar.php">Daftar</a></li>
                    <?php endif; ?>
                </ul>
            </li>
        </ul>
    </div>
</nav>

<!-- HERO -->
<div class="container hero text-center">
    <h1 class="mb-2">Selamat Datang di Morry48 Store</h1>
    <p>Temukan produk menarik di toko kami</p>
</div>

<!-- SEARCH -->
<div class="container mb-4">
    <form action="index.php" method="POST" class="search-wrap">
        <div class="input-group">
            <input type="text" name="search" value="<?= htmlspecialchars($searchQuery); ?>"
                   class="form-control search-input"
                   placeholder="Cari produk... (contoh: lanyard, keychain)">
            <button class="btn btn-primary search-btn" type="submit">Cari</button>
        </div>
    </form>
</div>

<!-- PRODUCTS -->
<div class="container pb-5">
    <div class="row g-4">
        <?php if ($result && mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="card product-card">
                        <div class="product-img-wrap">
                            <img class="product-img"
                                 src="admin/upload/<?= htmlspecialchars($row['gambar']); ?>"
                                 alt="<?= htmlspecialchars($row['nama_produk']); ?>">
                        </div>
                        <div class="product-body">
                            <div class="product-title"><?= htmlspecialchars($row['nama_produk']); ?></div>
                            <div class="product-price">
                                Rp <?= number_format((int)$row['harga'], 0, ',', '.'); ?>
                            </div>

                            <div class="d-grid gap-2">
                                <a href="detail_produk.php?id=<?= (int)$row['id_produk']; ?>"
                                   class="btn btn-info btn-soft">
                                    Detail
                                </a>

                                <!-- sesuaikan dengan sistem kamu:
                                     kalau add-to-cart kamu pakai keranjang.php?add=ID, biarkan.
                                     kalau kamu pakai tambah_keranjang.php?id=ID, ganti link-nya. -->
                                <a href="tambah_keranjang.php?id=<?= (int)$row['id_produk']; ?>"
                                   class="btn btn-primary btn-soft">
                                    Tambah ke Keranjang
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-warning text-center">
                    Produk tidak ditemukan.
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- FOOTER -->
<div class="container footer text-center">
    &copy; <?= date('Y'); ?> Morry48 Store | All Rights Reserved
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
