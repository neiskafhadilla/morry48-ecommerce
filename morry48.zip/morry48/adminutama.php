<?php
include('config/koneksi.php');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Admin Morry48</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h1>Dashboard Admin Morry48</h1>
    <a href="tambah_produk.php">+ Tambah Produk</a>
    <hr>
    <table border="1" align="center" cellpadding="10">
        <tr>
            <th>ID</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Gambar</th>
        </tr>
        <?php
        $data = mysqli_query($koneksi, "SELECT * FROM produk");
        while ($row = mysqli_fetch_array($data)) {
        ?>
        <tr>
            <td><?php echo $row['id_produk']; ?></td>
            <td><?php echo $row['nama_produk']; ?></td>
            <td>Rp<?php echo number_format($row['harga']); ?></td>
            <td><?php echo $row['stok']; ?></td>
            <td><img src="../assets/img/<?php echo $row['gambar']; ?>" width="80"></td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
