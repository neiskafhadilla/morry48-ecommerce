<?php
session_start();
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Periksa apakah username dan password tidak kosong
    if ($username !== '' && $password !== '') {
        // Query untuk memeriksa kecocokan username dan password
        $sql = "SELECT * FROM user WHERE username = ? AND password = ?";
        $stmt = mysqli_prepare($koneksi, $sql);
        mysqli_stmt_bind_param($stmt, 'ss', $username, $password);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);
            // Set session untuk login
            $_SESSION['id_user'] = $user['id_user'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['level'] = $user['level'];

            // Cek level pengguna dan arahkan sesuai level
            if ($user['level'] === 'admin') {
                // Jika admin, arahkan ke dashboard admin
                header('Location: halamanutama.php');
                exit;
            } else {
                // Jika pelanggan, arahkan ke halaman beranda toko
                header('Location: index.php');
                exit;
            }
        } else {
            // Jika login gagal
            echo "<script>alert('Username atau password salah!');window.location='login.php';</script>";
        }
    } else {
        echo "<script>alert('Username atau password tidak boleh kosong!');window.location='login.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h2 class="text-center">Login</h2>
    <form method="POST" action="login.php">
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="username" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary">Login</button>
        <p class="mt-3">Belum punya akun? <a href="daftar.php">Daftar di sini</a></p>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
